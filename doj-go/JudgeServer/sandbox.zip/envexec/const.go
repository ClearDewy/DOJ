package envexec

const (
	defaultExtraMemoryLimit = Size(16 << 10) // 16k more memory
)
