// Package pool provides reference implementation for envexec.EnvironmentPool from EnvBuilder
package pool
