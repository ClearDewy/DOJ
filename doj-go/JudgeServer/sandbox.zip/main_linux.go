package main

import (
	"github.com/criyle/go-sandbox/container"
)

func init() {
	container.Init()
}
